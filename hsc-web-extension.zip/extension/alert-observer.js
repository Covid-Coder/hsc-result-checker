// MAIN world: observe the official site's native alert without suppressing or solving anything.
(()=>{const original=window.alert;window.alert=function(message){window.postMessage({source:'hsc-official-native-alert',text:String(message).slice(0,60000)},location.origin);return original.call(window,message);};})();
