const OFFICIAL='https://www.educationboardresults.gov.bd/',LOCAL='https://covid-coder.github.io/hsc-result-checker/';
const officialURL=url=>{try{return new URL(url).origin===new URL(OFFICIAL).origin;}catch{return false;}};
const localURL=url=>{try{const u=new URL(url),base=new URL(LOCAL);return u.origin===base.origin&&u.pathname.startsWith(base.pathname);}catch{return false;}};
async function publish(state){const tabs=await chrome.tabs.query({url:LOCAL+'*'});for(const tab of tabs)chrome.tabs.sendMessage(tab.id,{type:'official-state',state}).catch(()=>{});}
async function boundTab(create){
 const saved=await chrome.storage.session.get('officialTab');let tab;
 try{if(saved.officialTab)tab=await chrome.tabs.get(saved.officialTab);}catch{}
 if(tab&&!officialURL(tab.url))throw Error('Official tab অন্য সাইটে গেছে। সেটি বন্ধ করে Connect করুন।');
 if(!tab&&create){tab=await chrome.tabs.create({url:OFFICIAL,active:true});await chrome.storage.session.set({officialTab:tab.id});}
 if(!tab)throw Error('একই official tab সংযুক্ত নেই। Connect to Site চাপুন।');return tab;
}
async function command(message){
 const tab=await boundTab(message.action==='connect');
 if(['connect','focus','fill','submit'].includes(message.action)){await chrome.tabs.update(tab.id,{active:true});if(tab.windowId)await chrome.windows.update(tab.windowId,{focused:true});}
 try{return await chrome.tabs.sendMessage(tab.id,{type:'official-command',action:message.action,values:message.values});}
 catch{return {phase:'loading',error:'Official tab লোড হচ্ছে বা extension reload দরকার। Official tab-এ verification নিজে শেষ করে আবার Connect চাপুন।'};}
}
chrome.runtime.onMessage.addListener((message,sender,respond)=>{
 if(message.type==='local-command'&&localURL(sender.url)){command(message).then(respond).catch(error=>respond({phase:'disconnected',error:error.message}));return true;}
 if(message.type==='official-update'&&officialURL(sender.url))chrome.storage.session.get('officialTab').then(saved=>{if(sender.tab?.id===saved.officialTab)publish(message.state);});
});
chrome.tabs.onRemoved.addListener(id=>{chrome.storage.session.get('officialTab').then(saved=>{if(saved.officialTab===id){chrome.storage.session.remove('officialTab');publish({phase:'disconnected',error:'Official tab বন্ধ হয়েছে। পুনরায় সংযোগ করুন।'});}});});
chrome.tabs.onUpdated.addListener((id,change)=>{if(change.status==='loading')chrome.storage.session.get('officialTab').then(saved=>{if(saved.officialTab===id)publish({phase:'loading',error:'একই official tab-এ পৃষ্ঠা লোড হচ্ছে…'});});});
