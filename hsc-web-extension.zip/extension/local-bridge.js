window.addEventListener('message',async event=>{
 if(event.source!==window||event.origin!==location.origin||event.data?.source!=='hsc-page')return;
 const {id,action,values}=event.data;if(!['connect','state','fill','submit','focus'].includes(action))return;
 try {const data=await chrome.runtime.sendMessage({type:'local-command',action,values});window.postMessage({source:'hsc-extension',id,data},location.origin);}
 catch{window.postMessage({source:'hsc-extension',id,data:{error:'Extension bridge বন্ধ হয়েছে। পৃষ্ঠা reload করুন।'}},location.origin);}
});
chrome.runtime.onMessage.addListener(message=>{if(message.type==='official-state')window.postMessage({source:'hsc-extension',event:'state',data:message.state},location.origin);});
