(()=>{
 if(globalThis.HSC_OFFICIAL_BRIDGE)return;globalThis.HSC_OFFICIAL_BRIDGE=true;
 const ORIGIN='https://www.educationboardresults.gov.bd';let pending=false,lastSignature='',timer,lastAlert='';
 const names={exam:['exam','examination','examinationtype'],year:['year','examyear'],board:['board','educationboard'],roll:['roll','roll_no','rollno','rollnumber'],registration:['reg','registration','regno','reg_no','registration_no','registrationnumber']};
 function field(key){const all=[...document.querySelectorAll('input,select')].filter(el=>names[key].includes((el.name||el.id||'').toLowerCase())&&!el.disabled&&el.type!=='hidden');return all.length===1?all[0]:null;}
 function text(){const panel=document.getElementById('hsc-session-panel');return (document.body?.innerText||'').replace(panel?.innerText||'\u0000','').slice(0,60000);}
 function state(){
  const page=text();if(location.origin!==ORIGIN)return {phase:'disconnected',error:'Official origin মেলেনি।'};
  if(location.pathname.includes('_challenge')||/verifying you are|preparing verification|not a robot|verify you are human/i.test(page))return {phase:'human_verification',error:'এই official tab-এ human verification নিজে সম্পন্ন করুন। এটি পরীক্ষার CAPTCHA নয়।',source:location.href};
  if(/session (?:has )?expired|invalid session|সেশন.*(?:মেয়াদ শেষ|মেয়াদ শেষ)/i.test(page))return {phase:'disconnected',error:'Official পৃষ্ঠায় session মেয়াদ শেষ/অকার্যকর বলা হয়েছে। একই tab-এ আবার form খুলে পুনঃসংযোগ করুন।',source:location.href};
  if(pending)return {phase:'submitting',source:location.href};
  if(lastAlert){const mismatch=/(?:invalid|incorrect|wrong)\s+(?:captcha|security code)|(?:captcha|security code).*?(?:did not match|does not match|incorrect|invalid)/i.test(lastAlert);return {phase:mismatch?'captcha_mismatch':'official_response',canFill:Object.keys(names).every(k=>field(k)),source:location.href,responseText:lastAlert,message:mismatch?'Official server CAPTCHA না-মেলার বার্তা দিয়েছে। তথ্য অক্ষত আছে।':'Official server-এর আসল popup বার্তা নিচে দেখানো হয়েছে।'};}
  if(/(?:invalid|incorrect|wrong)\s+(?:captcha|security code)|(?:captcha|security code)\s+(?:does not match|did not match|is incorrect|is invalid)|ক্যাপচা\s*(?:মেলেনি|সঠিক নয়)/i.test(page))return {phase:'captcha_mismatch',message:'Official পৃষ্ঠায় CAPTCHA ভুল/না-মেলার বার্তা পাওয়া গেছে। আগের তথ্য অক্ষত; নতুন CAPTCHA official tab-এ পূরণ করুন।',responseText:page,source:location.href};
  const options={};for(const key of ['exam','year','board']){const el=field(key);if(!el||el.tagName!=='SELECT')break;options[key]=[...el.options].filter(o=>o.value&&!o.disabled&&!/^(0|-1)$/.test(o.value)&&!/^[-\s]*(select|choose|নির্বাচন)/i.test(o.text)).map(o=>({value:o.value,label:o.text.trim()}));}
  if(['exam','year','board'].every(k=>options[k]?.length)&&field('roll')&&field('registration'))return {phase:pending?'submitting':'form',options,source:location.href,canFill:true};
  return {phase:'official_response',source:location.href,responseText:page,message:'একই official tab-এর বর্তমান উত্তর। ফল আছে কি না নিচের আসল লেখা ও official tab দেখে যাচাই করুন।'};
 }
 function officialForm(){const els=Object.keys(names).map(field);if(els.some(e=>!e))throw Error('পাঁচটি official field স্পষ্টভাবে পাওয়া যায়নি। Official form নিজে ব্যবহার করুন।');const form=els[0].form;if(!form||els.some(e=>e.form!==form))throw Error('একটি অভিন্ন official form পাওয়া যায়নি।');const action=new URL(form.action||location.href,location.href);if(action.origin!==ORIGIN)throw Error('Form অন্য origin-এ পাঠায়; helper থেমেছে।');return {form,els};}
 function fill(values){
  if(!['form','captcha_mismatch'].includes(state().phase)&&!(lastAlert&&state().canFill))throw Error('Official form প্রস্তুত নয়। Verification শেষ করুন।');
  const {els}=officialForm();const keys=Object.keys(names);
  lastAlert='';
  for(let i=0;i<keys.length;i++){const v=String(values?.[keys[i]]||'');if(!v||v.length>200)throw Error('তথ্য অসম্পূর্ণ।');if(els[i].tagName==='SELECT'&&![...els[i].options].some(o=>o.value===v&&!o.disabled))throw Error(keys[i]+' official option বদলেছে। আবার Connect করুন।');}
  if(!/^\d{6}$/.test(values.roll)||!/^\d{10}$/.test(values.registration))throw Error('রোল/রেজিস্ট্রেশন ভুল।');
  // Verified on the current official /v2/home: type 1 reveals individual roll/CAPTCHA fields.
  const resultType=document.querySelector('#result_type');
  if(resultType){if(resultType.tagName!=='SELECT'||![...resultType.options].some(o=>o.value==='1'&&/Individual\/Detailed Result/i.test(o.text)))throw Error('Individual Result option বদলেছে। Official tab নিজে ব্যবহার করুন।');resultType.value='1';resultType.dispatchEvent(new Event('change',{bubbles:true}));}
  for(let i=0;i<keys.length;i++){els[i].value=values[keys[i]];els[i].dispatchEvent(new Event('input',{bubbles:true}));els[i].dispatchEvent(new Event('change',{bubbles:true}));}
  if(els.some((el,i)=>el.value!==values[keys[i]]))throw Error('Official form তথ্য গ্রহণ করেনি বা option বদলেছে। Official tab-এ নিজে মিলিয়ে নিন।');
  return {...state(),filled:true,message:'তথ্য এই official tab-এ বসেছে। CAPTCHA নিজে পূরণ করে “ফলাফল দেখুন” চাপুন।'};
 }
 function submit(){
  if(pending)throw Error('একটি submission চলছে; অপেক্ষা করুন।');if(!['form','captcha_mismatch'].includes(state().phase))throw Error('Official form প্রস্তুত নয়।');
  const {form,els}=officialForm();if(!form.reportValidity())throw Error('Official form-এর প্রয়োজনীয় ঘর পূরণ করুন।');
  const extras=[...form.querySelectorAll('input')].filter(el=>!els.includes(el)&&!['hidden','submit','button','reset'].includes(el.type)&&!el.disabled&&el.getClientRects().length);
  if(extras.some(el=>el.type==='password'))throw Error('অপ্রত্যাশিত password form; নিজে official site ব্যবহার করুন।');
  const captcha=extras.filter(el=>['text','number','tel'].includes(el.type));if(captcha.length!==1||!captcha[0].value.trim())throw Error('Official tab-এ আসল CAPTCHA নিজে পূরণ করুন। ঘর নিশ্চিত করা না গেলে সাইটের নিজস্ব Submit ব্যবহার করুন।');
  const buttons=[...form.querySelectorAll('button,input[type=submit]')].filter(el=>(el.tagName==='INPUT'||el.type==='submit')&&!el.disabled);
  if(buttons.length!==1)throw Error('Official Submit button স্পষ্ট নয়; সাইটের নিজের Submit চাপুন।');
  lastAlert='';pending=true;publish();buttons[0].click();setTimeout(()=>{pending=false;publish();},15000);return {phase:'submitting',message:'একই official form submit করা হয়েছে; official উত্তর আসার অপেক্ষা।'};
 }
 function panel(){
  if(document.getElementById('hsc-session-panel'))return;
  const box=document.createElement('aside');box.id='hsc-session-panel';box.style='position:fixed;right:10px;bottom:10px;z-index:2147483647;max-width:320px;background:white;color:#173b3a;border:2px solid #08766b;padding:14px;font:16px sans-serif';
  const p=document.createElement('p');p.textContent='স্থানীয় HSC bridge: CAPTCHA নিজে লিখুন। Cookies এই tab-এই থাকে।';const b=document.createElement('button');b.textContent='ফলাফল দেখুন';b.onclick=()=>{try{const data=submit();p.textContent=data.message;}catch(e){p.textContent=e.message;}};
  box.append(p,b);document.body.append(box);
 }
 function publish(){const s=state(),signature=JSON.stringify(s);if(signature===lastSignature)return;lastSignature=signature;chrome.runtime.sendMessage({type:'official-update',state:s}).catch(()=>{});}
 chrome.runtime.onMessage.addListener((m,sender,respond)=>{if(m.type!=='official-command')return;try{if(m.action==='fill')respond(fill(m.values));else if(m.action==='submit')respond(submit());else respond(state());}catch(e){respond({phase:'error',error:e.message});}});
 window.addEventListener('message',event=>{if(event.source===window&&event.origin===ORIGIN&&event.data?.source==='hsc-official-native-alert'){lastAlert=String(event.data.text).slice(0,60000);pending=false;publish();}});
 panel();publish();new MutationObserver(()=>{clearTimeout(timer);timer=setTimeout(publish,500);}).observe(document.body,{childList:true,subtree:true,characterData:true});window.addEventListener('pageshow',publish);
})();
